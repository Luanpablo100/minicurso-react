import React from 'react'

const App = () => {
  const message = "Boa tarde"
  return (
    <h1>{message}</h1>
  )
}

export default App